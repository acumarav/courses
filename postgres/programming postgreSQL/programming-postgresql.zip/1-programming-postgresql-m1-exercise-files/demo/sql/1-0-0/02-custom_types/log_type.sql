create type log_type as ENUM(
  'Registration',
  'Authentication',
  'Activity',
  'System'
);
