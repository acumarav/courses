package learningspringboot;

public enum Severity {

	UP, DEGRADED, JEOPARDY, DOWN
}
