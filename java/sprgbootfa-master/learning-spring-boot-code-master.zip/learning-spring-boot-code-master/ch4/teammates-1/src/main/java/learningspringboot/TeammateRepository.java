package learningspringboot;

import org.springframework.data.repository.CrudRepository;

public interface TeammateRepository extends CrudRepository<Teammate, Long> {}
