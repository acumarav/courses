insert into team
(id, name)
values
(1, 'Spring Boot Badgers');

insert into teammate
(id, first_name, last_name, position, team_id) values
(1, 'Greg', 'Turnquist', '2nd base', 1);

insert into teammate (id, first_name, last_name, position, team_id) values
(2, 'Roy', 'Clarkson', '1st base', 1);

insert into teammate
(id, first_name, last_name, position, team_id) values
(3, 'Phil', 'Webb', 'pitcher', 1);