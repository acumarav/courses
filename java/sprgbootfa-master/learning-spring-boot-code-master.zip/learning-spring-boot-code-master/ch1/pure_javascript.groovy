@Controller 
class JsApp { }
